Code for CSO1 simulator lab; see <https://www.cs.virginia.edu/~jh2jf/courses/cs2130/spring2023/labs/lab4-simulator.html> for more.

All example inputs on the writeup are also provided in the `programs/` directory.
