scp cir.tgz pfalstad@204.14.92.15:
